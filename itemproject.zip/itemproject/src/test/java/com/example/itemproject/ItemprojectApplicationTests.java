package com.example.itemproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
