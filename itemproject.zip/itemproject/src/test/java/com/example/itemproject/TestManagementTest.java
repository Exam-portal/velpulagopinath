package com.example.itemproject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestManagementTest {


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.Management;
import org.springframework.boot.test.context.SpringBootTest;

import com.dao.TestManagementdaoimpl;
import com.niteesh.onlineexam.dao.TestManagementService;
import com.niteesh.onlineexam.model.TestManagement;

import Controller.TestManagementcontroller;

@SpringBootTest
class TestManagementTests {

	@Autowired
	TestManagementcontroller service;

	@Test
	void testAdd() {

		Management test = new TestManagementdaoimpl();
		test.setCourseType("java");
		service.add(test);

		Management test_to_be_added = service.findTest(test.getTest_Id());
		assertEquals("java", test_to_be_added.getCourseType());
	}

	@Test
	void testFindTest() {

		Management test = new TestManagementdaoimpl();
		test.setCourseType("python");
		service.add(test);

		TestManagement test_to_be_find = service.findTest(test.getTest_Id());
		assertEquals("python", test_to_be_find.getCourseType());

	}

	@Test
	void testFindAllTest() {

		TestManagement test = new TestManagement();
		test.setCourseType("devops");
		service.add(test);

		TestManagement test_to_be_findAllTest = service.findTest(test.getTest_Id());
		assertEquals("devops", test_to_be_findAllTest.getCourseType());

	}

	@Test
	void testUpdateTest() {

		TestManagement test1 = new TestManagement();
		test1.setCourseType("core java");
		service.add(test1);
		test1.setCourseType("oops");
		service.updateTest(test1);
		assertEquals(true, service.updateTest(test1));

	}

//	@Test
//	void testDeleteTest() {
//
//		TestManagement test_to_be_deleted = service.findTest(3);
//		service.deleteTest(3);
//		assertNotNull(test_to_be_deleted);
//	}

}

