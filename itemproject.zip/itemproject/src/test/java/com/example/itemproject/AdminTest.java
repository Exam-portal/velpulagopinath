package com.example.itemproject;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AdminTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
mport static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cglib.beans.BulkBeanException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.mvc.AbstractController;

import com.dao.AdminDAO;
import com.dao.Adminservice;
import com.niteesh.onlineexam.controller.AdminController;
import com.niteesh.onlineexam.controller.ChangePasswordException;
import com.niteesh.onlineexam.controller.LoginException;
import com.niteesh.onlineexam.controller.ViewProfieException;
import com.niteesh.onlineexam.dao.AdminService;
import com.niteesh.onlineexam.model.Admin;

import Controller.changepasswordexception;

@SpringBootTest
class AdminTests {

	@Autowired
	AbstractController adminController;

	@Autowired
	Adminservice adminService;
	
	@Test
	void testLoginSuccess() {
		AdminDAO admin = new AdminDAO();
		admin.setId(1);
		admin.setPassword("1234");
		assertEquals(ResponseEntity.ok("Success"), adminController.login(admin));
	}
	
	@Test
	void testLoginFailure() {
		try {
			adminController.login(null);
	        assert false;
	    } catch (BulkBeanException e) {
	    	assertEquals(e.toString(), "invalid login details");
	        assert true;
	    }
	}
	
	@Test
	void changePasswordSuccess() {
		Admin admin = new Admin();
		admin.setId(2);
		admin.setName("Dharma");
		admin.setEmail("XYZ@gmail.com");
		admin.setAddress("XYZ street");
		admin.setPassword("2222");
		adminService.add(admin);
		List<AdminDAO> admins=adminService.findAllAdmin();
		assertEquals(ResponseEntity.ok("admin password changed successfully"), adminController.changePassword(admins.get(admins.size()-1)));
	}
	
	@Test
	void changePasswordFailure() {
		try {
			adminController.changepassword(null);
	        assert false;
	    } catch (changepasswordexception e) {
	    	assertEquals(e.toString(), "Unable to change password");
	        assert true;
	    }
	}
	
	@Test
	void getUserProfileSuccess() {
		Admin admin = new Admin();
		admin.setId(2);
		admin.setName("Dharma");
		admin.setEmail("XYZ@gmail.com");
		admin.setAddress("XYZ street");
		admin.setPassword("2222");
		adminService.add(admin);
		List<Admin> admins=adminService.findAllAdmin();
		assertNotNull(adminController.getUserProfile(admins.get(admins.size()-1).getId()));
	}
	
	@Test
	void getUserProfileFailure() {
		try {
			adminController.getUserProfile(0);
	        assert false;
	    } catch (viewprofileexception e) {
	    	assertEquals(e.toString(), "profile data not found");
	        assert true;
	    }
	}

}