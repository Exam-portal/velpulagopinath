package Controller;


public class changepasswordexception extends RuntimeException{
	
	public changepasswordexception() {
		super("password cannot be changed successfully");
	}
	public String toString() {
		return "Unable to change password";
	}

}
