package Controller;





public class loginexception extends RuntimeException {
	
	public loginexception() {
		super("login will not be  successfull");
	}

	public  String toString() {
		return "invalid login details";
	}
}

