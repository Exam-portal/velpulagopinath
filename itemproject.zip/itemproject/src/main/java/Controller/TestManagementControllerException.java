package Controller;





import org.hibernate.CallbackException;
import org.springframework.cglib.beans.BulkBeanException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class TestManagementControllerException {

	@ExceptionHandler(findtestresult.class)
	public ResponseEntity<?> changePasswordException(findtestresult e, WebRequest req) {
		return new ResponseEntity<>(e, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(BulkBeanException.class)
	public ResponseEntity<?> loginException(CallbackException e, WebRequest req) {
		return new ResponseEntity<>(e, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(ViewresultException.class)
	public ResponseEntity<?> viewProfieException(ViewresultException e, WebRequest req) {
		return new ResponseEntity<>(e, HttpStatus.NOT_FOUND);
	}

}