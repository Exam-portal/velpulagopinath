package Controller;





import javax.swing.text.BadLocationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.beans.BulkBeanException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.*;


@RestController
public class TestManagementcontroller {

	@Autowired
	TestManagementservice service;

	@GetMapping("/login")
	public ResponseEntity<?> login(@RequestBody Test test) throws BulkBeanException{
		if(test==null) {
			throw new BadLocationException();
		}
		return ResponseEntity.ok(service.login(test));
	}
	
	@PostMapping("/changePassword")
	public ResponseEntity<?> changePassword(@RequestBody Test test) throws ChangePasswordException{
		if(test==null) {
			throw new ChangePasswordException();
		}
		service.changePassword(test);
		return ResponseEntity.ok("admin password changed successfully");
	}

	@GetMapping("/profile/{userId}")
	public ResponseEntity<?> getUserProfile(@PathVariable(value = "userId") int userId) throws ViewProfieException {
		if (userId <= 0) {
			throw new ViewProfieException();
		}
		return ResponseEntity.ok(service.findTest(userId));
	}

}
