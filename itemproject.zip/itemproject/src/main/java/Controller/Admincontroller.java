package Controller;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dao.Adminservice;




@RestController
public class Admincontroller {

	@Autowired
	Adminservice service;

	@GetMapping("/login")
	public ResponseEntity<?> login(@RequestBody Admin admin) throws loginexception{
		if(admin==null) {
			throw new loginexception();
		}
		return ResponseEntity.ok(service.login(admin));
	}
	
	@PostMapping("/changePassword")
	public ResponseEntity<?> changePassword(@RequestBody Admin admin) throws changepasswordexception{
		if(admin==null) {
			throw new changepasswordexception();
		}
		service.changePassword(admin);
		return ResponseEntity.ok("admin password changed successfully");
	}

	@GetMapping("/profile/{userId}")
	public ResponseEntity<?> getUserProfile(@PathVariable(value = "userId") int userId) throws viewprofile {
		if (userId <= 0) {
			throw new viewprofile();
		}
		return ResponseEntity.ok(service.findAdmin(userId));
	}

}
