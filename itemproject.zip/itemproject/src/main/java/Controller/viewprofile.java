package Controller;





public class viewprofile extends RuntimeException {

	public viewprofile() {
		super("profile data not found");
	}

	public String toString() {
		return "profile data not found";
	}
}
