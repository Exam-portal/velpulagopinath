package com.dao;





import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.stereotype.Component;

import com.dao.*;
import com.sun.org.apache.xpath.internal.operations.Equals;

@Component
public class Admindaoimpl {
public class viewprofie extends RuntimeException {

	public viewprofie() {
		super("profile data not found");
	}

	public String toString() {
		return "profile data not found";
	}
}


private SessionFactory sessionFactory;
{
	
	SessionFactory sessionFactory;

	public void addAdmin(Admin admin) {
		
		Session session = sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(admin);
		session.flush();
		session.getTransaction().commit();
		session.close();

	}
	
	
	public Admin findAdmin(int id) {

		Session session = sessionFactory.openSession();
		Admin admin = session.find(Admin.class, id);
		return admin;
	}

	
	public List<Admin> findAllAdmin() {
		Session session = sessionFactory.openSession();
		List<Admin> adminlist = session.createQuery("select a from Admin a").list();
		return adminlist;
	}

	
	public boolean updateAdmin(Admin admin) {
		Session session = sessionFactory.openSession();
		session.getTransaction().begin();
		session.update(admin);
		session.flush();
		session.getTransaction().commit();
		session.close();
		return true;
	}

	
	public boolean deleteAdmin(int id) {
		Session session = sessionFactory.openSession();
		session.getTransaction().begin();
		Admin admin = session.find(Admin.class, id);
		session.delete(admin);
		session.flush();
		session.getTransaction().commit();
		session.close();
		return true;
	}


	public boolean createAdmin(int id) {
		Session session = sessionFactory.openSession();
		session.getTransaction().begin();
		Admin admin = session.find(Admin.class, id);
		session.update(admin);
		session.flush();
		session.getTransaction().commit();
		session.close();
		return true;
	}

	
	public String login(Admin admin) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("select a from Admin a where a.id = :adminId and a.password = :password");
		Admin adminDetails = session.find(Admin.class, admin.getSsl());
		if(adminDetails.getpassword()Equals.class)
			return "Success";
		}
		return "Fail";
	}

	
	private Object getPassword() {
		// TODO Auto-generated method stub
		return null;
	}


	public void changePassword(Admin admin) {
		Session session = sessionFactory.openSession();
		session.getTransaction().begin();
		Admin adminDetails = session.find(Admin.class, admin.getSsl());
		adminDetails.setPassword(admin.getPassword);
		session.update(adminDetails);
		session.flush();
		session.getTransaction().commit();
		session.close();
	}

}
