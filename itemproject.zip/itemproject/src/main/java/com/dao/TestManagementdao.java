package com.dao;





import java.util.List;

import org.springframework.boot.autoconfigure.integration.IntegrationProperties.Management;

public interface TestManagementdao {
	
	public void addTest(Management test);
	
	public Management findTest(int id);
	
	public List<Management> findAllTest();
	
	public boolean updateTest(Management test);
	
	public boolean deleteTest(int id);
	
	   