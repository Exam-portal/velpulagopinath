package com.dao;



import java.util.List;

import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminDAO {
	
public void addAdmin(Admin admin);
	
	public Admin findAdmin(int id);
	
	public List<Admin> findAllAdmin();
	
	public boolean updateAdmin(Admin admin);
	    
	public boolean deleteAdmin(int id);
	
	public boolean createAdmin( int id);
	
	public String login(Admin admin);
	
    public void changePassword(Admin admin);

}