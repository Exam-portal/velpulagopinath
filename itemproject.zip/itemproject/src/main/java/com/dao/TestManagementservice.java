package com.dao;





import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.Management;
import org.springframework.stereotype.Service;

import com.dao.*;

@Service
public class TestManagementservice {
	
	@Autowired
	TestManagementdao test_MgmtDAOImpl;
	
	public void add(Management test) {
		
		test_MgmtDAOImpl.addTest(test);
	}
	
	public Management findTest(int id) {
		
		return  test_MgmtDAOImpl.findTest(id);
	}
	
	public List<Management> findAllTest(){
		
		return test_MgmtDAOImpl.findAllTest();
		
	}
	
	public boolean updateTest(Management test) {
		
		return test_MgmtDAOImpl.updateTest(test);
	}
	
	public boolean deleteTest(int id) {
		
		return test_MgmtDAOImpl.deleteTest(id);
	}
      




	
	

}
