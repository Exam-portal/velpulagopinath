package com.dao;



import java.util.List;        
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationProperties.Management;
import org.springframework.stereotype.Component;

import com.dao.*;

import org.hibernate.Session;
import org.hibernate.*;
@Component
public class TestManagementdaoimpl implements TestManagementdao {
	    
     @Autowired
     SessionFactory sessionFactory;
	public void addTest(Management test) {
        Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(test);
		session.flush();
		session.getTransaction().commit();
		session.close();
	}
     
	public Management findTest(int id) {
		
		Session session=sessionFactory.openSession();
	    Management test=session.find(Management.class, id);
		return test;
	}

	public List<Management> findAllTest() {
		Session session=sessionFactory.openSession();
		List<Management> testlist=session.createQuery("select t from Test t").list();
		return testlist;

	}
    public boolean updateTest(Management test) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.update(test);
		session.flush();
		session.getTransaction().commit();
		session.close();
		return true;
		
	}

	public boolean deleteTest(int id) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		Management test = session.find(Management.class,id);
		session.delete(test);
		session.flush();
		session.getTransaction().commit();
		session.close();
		return true;
		
	}





	
}
