package com.example.itemproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItemprojectApplication.class, args);
	}

}
